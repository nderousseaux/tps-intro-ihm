create PACKAGE GestionFinanciere IS
   Procedure augmentMontant(employe emp.empno%TYPE, montant emp.sal%TYPE);
   Procedure afficheSalEmp(employe emp.empno%TYPE);
   Procedure annuaire;
   Procedure augmentPourcent(employe emp.empno%TYPE, pourcent NUMBER, nouvSal OUT emp.sal%TYPE);
   Function revenuAnnuel(employe emp.empno%TYPE) RETURN emp.sal%TYPE;
   Function revenuAnnuelPromoAnc(employe emp.empno%TYPE) RETURN emp.sal%TYPE;
end GestionFinanciere;
/

