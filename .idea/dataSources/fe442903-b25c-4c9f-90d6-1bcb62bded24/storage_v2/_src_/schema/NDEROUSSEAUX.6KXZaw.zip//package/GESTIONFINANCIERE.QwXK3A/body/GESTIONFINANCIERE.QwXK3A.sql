create PACKAGE BODY gestionFinanciere IS

PROCEDURE augmentMontant(employe emp.empno%TYPE, montant emp.sal%TYPE) AS
BEGIN
   UPDATE emp
   SET sal = sal + montant
   WHERE empno=employe;
END augmentMontant;

PROCEDURE afficheSalEmp(employe emp.empno%TYPE) AS
   salaire emp.empno%TYPE;
BEGIN
   SELECT sal INTO salaire FROM emp WHERE empno=employe;
   DBMS_OUTPUT.PUT_LINE('Salaire de l''employé '||employe||' : '||salaire);
END afficheSalEmp;

PROCEDURE annuaire AS
   CURSOR c IS SELECT ename, job, deptno FROM emp;
BEGIN
   FOR e IN c LOOP
     DBMS_OUTPUT.PUT_LINE('Employé : '||e.ename||' - Fonction : '||NVL(e.job,'aucune')||' - Département : '||e.deptno);
   END LOOP;
END;

PROCEDURE  augmentPourcent(employe emp.empno%TYPE, pourcent NUMBER, nouvSal OUT emp.sal%TYPE) AS
BEGIN
   SELECT sal*(1+pourcent/100) INTO nouvSal
   FROM emp
   WHERE empno=employe;

   UPDATE emp
   SET sal=nouvSal
   WHERE empno=employe;
END augmentPourcent;

FUNCTION revenuAnnuel(employe emp.empno%TYPE) RETURN emp.sal%TYPE AS
   revenu emp.sal%TYPE;
BEGIN
   SELECT sal+nvl(comm,0) INTO revenu
   FROM emp
   WHERE empno=employe;

   RETURN revenu;
END revenuAnnuel;

FUNCTION revenuAnnuelPromoAnc(employe emp.empno%TYPE) RETURN emp.sal%TYPE AS
   salaire emp.sal%TYPE;
   commission emp.comm%TYPE;
   anciennete NUMBER(2);
BEGIN
   SELECT sal, comm, MONTHS_BETWEEN(sysdate, hiredate)/12 INTO salaire,
commission, anciennete
   FROM emp WHERE empno = employe ;

   IF anciennete <10 THEN
      RETURN (salaire + nvl(commission,0))*12 + salaire ;
   ELSE
      RETURN (salaire + nvl(commission,0))*12 + salaire * (1+anciennete/100) ;
   END IF ;
END revenuAnnuelPromoAnc;

END gestionFinanciere ;
/

